import { Component, OnDestroy, OnInit, } from '@angular/core';

declare var $;
declare var Chart;
declare var randomScalingFactor;
declare var window;
declare var Samples;
@Component({
  selector: 'starter',
  templateUrl: 'starter.template.html'
})
export class StarterViewComponent implements OnDestroy, OnInit {

  public nav: any;

  public constructor() {
    this.nav = document.querySelector('nav.navbar');
  }

  values: number = 1545654;

  public ngOnInit(): any {
    this.nav.className += " white-bg";

    $(document).ready(() => {


      this.renaderNewChaartType();

      // // setTimeout(() => {
      var ctx = document.getElementById('myChart');
      var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
          datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
              'rgba(255, 99, 132, 0.2)',
              'rgba(54, 162, 235, 0.2)',
              'rgba(255, 206, 86, 0.2)',
              'rgba(75, 192, 192, 0.2)',
              'rgba(153, 102, 255, 0.2)',
              'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
              'rgba(255, 99, 132, 1)',
              'rgba(54, 162, 235, 1)',
              'rgba(255, 206, 86, 1)',
              'rgba(75, 192, 192, 1)',
              'rgba(153, 102, 255, 1)',
              'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
          }]
        },
        options: {
          scales: {
            yAxes: [{
              ticks: {
                beginAtZero: true
              }
            }]
          }
        }
      });



      var barChartData = {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
        datasets: [{
          label: 'Peak',
          backgroundColor: window.chartColors.red,
          data: [
            10,
            10,
            10,
            10,
            10,
            10,
            10
          ]
        }, {
          label: 'NonPeak',
          backgroundColor: window.chartColors.blue,
          data: [
            20,
            20,
            20,
            20,
            20,
            20,
            20
          ]
        }, {
          label: 'Dataset 3',
          backgroundColor: window.chartColors.green,
          data: [
            25,
            25,
            25,
            25,
            25,
            25,
            25
          ]
        }]

      };

      var ctx = document.getElementById('barChartData').getContext('2d');
      window.myBar = new Chart(ctx, {
        type: 'bar',
        data: barChartData,
        options: {
          title: {
            display: true,
            text: 'Chart.js Bar Chart - Stacked'
          },
          tooltips: {
            mode: 'index',
            intersect: false
          },
          responsive: true,
          scales: {
            xAxes: [{
              stacked: true,
            }],
            yAxes: [{
              stacked: true
            }]
          }
        }
      });

    });

  }


  public ngOnDestroy(): any {
    this.nav.classList.remove("white-bg");
  }

  renaderNewChaartType() {
    var DATA_COUNT = 16;

    var utils = Samples.utils;

    utils.srand(110);

    function colorize(opaque, ctx) {
      var v = ctx.dataset.data[ctx.dataIndex];
      var c = v < -50 ? '#D60000'
        : v < 0 ? '#F46300'
          : v < 50 ? '#0358B6'
            : '#44DE28';

      return opaque ? c : utils.transparentize(c, 1 - Math.abs(v / 150));
    }

    function generateData() {
      return utils.numbers({
        count: DATA_COUNT,
        min: -100,
        max: 100
      });
    }

    var data = {
      labels: utils.months({ count: DATA_COUNT }),
      datasets: [{
        data: generateData()
      }]
    };
    console.log(data);

    var options = {
      legend: false,
      tooltips: false,
      elements: {
        rectangle: {
          backgroundColor: colorize.bind(null, false),
          borderColor: colorize.bind(null, true),
          borderWidth: 2
        }
      }
    };
    console.log(options);
    var chart = new Chart('chart-0', {
      type: 'bar',
      data: data,
      options: {
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });

    // eslint-disable-next-line no-unused-vars
    function randomize() {
      chart.data.datasets.forEach(function (dataset) {
        dataset.data = generateData();
      });
      chart.update();
    }

    // eslint-disable-next-line no-unused-vars
    function addDataset() {
      chart.data.datasets.push({
        data: generateData()
      });
      chart.update();
      console.log(chart);
    }

    // eslint-disable-next-line no-unused-vars
    function removeDataset() {
      chart.data.datasets.shift();
      chart.update();
    }

    $("body").on("click", "#randomize", (e) => {
      randomize();
    });
    $("body").on("click", "#addDataset", (e) => {
      addDataset();
    });
    $("body").on("click", "#removeDataset", (e) => {
      removeDataset();
    });
  }

}
