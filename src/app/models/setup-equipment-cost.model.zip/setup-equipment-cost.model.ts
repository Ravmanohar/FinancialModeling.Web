//Start : On Street Equipment Cost Model
export class OnStreetEquipmentCostModel {
    singleSpaceMeters: Array<OnStreetModel> = new Array<OnStreetModel>();
    alternateOptions: OnStreetAlternateOption = new OnStreetAlternateOption();
}

export class OnStreetAlternateOption {
    singleSpaceMeters: OnStreetModel = new OnStreetModel(true, "singleSpaceMeters");
    dualSpaceMeters: OnStreetModel = new OnStreetModel(false, "dualSpaceMeters");
    payStations: OnStreetModel = new OnStreetModel(false, "payStations");
    mobileOnly: OnStreetModel = new OnStreetModel(false, "mobileOnly");
}

export class OnStreetModel {
    id: number = 0;
    name: string = "";
    unitsOwned: number = 0;
    unitsPurchased: number = 0;
    costOfBaseUnit: number = 0;
    warrantyStartingYear: number = 1;
    monthlyMeterSoftwareFees: number = 0;
    monthlyCreditCardProcessingFees: number = 0;
    estimatedCreditCardTransaction: number = 0;
    // isAlternateOption: boolean = false;
    isPrimary: boolean = false;
    clientId: number = 0;
    constructor(isPrimary: boolean = false, name: string = "") {
        this.isPrimary = isPrimary;
        this.name = name;
    }
}
//End : On Street Equipment Cost Model


//Start : Off Street Equipment Cost Model
export class OffStreetEquipmentCostModel {
    multiSpaceMeters: Array<OffStreetModel> = new Array<OffStreetModel>();
    alternateOptions: OffStreetAlternateOption = new OffStreetAlternateOption();
}

export class OffStreetModel {
    id: number = 0;
    name: string = "";
    unitsOwned: number = 0;
    unitsPurchased: number = 0;
    costOfBaseUnit: number = 0;
    warrantyStartingYear: number = 1;
    monthlyMeterSoftwareFees: number = 0;
    monthlyCreditCardProcessingFees: number = 0;
    estimatedCreditCardTransaction: number = 0;
    isAlternateOption: boolean = false;
    clientId: number = 0;
    constructor(isAlternateOption: boolean = false, name: string = "") {
        this.isAlternateOption = isAlternateOption;
        this.name = name;
    }
}

export class OffStreetAlternateOption {
    singleSpaceMeters: OffStreetModel = new OffStreetModel(true, "singleSpaceMeters");
}
//End : Off Street Equipment Cost Model

//Start : Garages Equipment Cost Model
export class GaragesEquipmentCostModel {
    garagesModels: Array<GaragesModel> = new Array<GaragesModel>();
    alternateOptions: GaragesAlternateOption = new GaragesAlternateOption();
}

export class GaragesModel {
    id: number = 0;
    name: string = "";
    unitsOwned: number = 0;
    unitsPurchased: number = 0;
    garageAccessPoints: number = 0;
    ingressEgressEquipmentCost: number = 0;
    payOnFootEquipWithBNA: number = 0;
    payOnFootEquipWithCreditCard: number = 0;
    annualSoftwareFeePerAccessPoint: number = 0;
    warranty: number = 0;
    monthlyCreditCardProcessingFees: number = 0;
    estimatedCreditCardTransaction: number = 0;
    isAlternateOption: boolean = false;
    clientId: number = 0;
    constructor(isAlternateOption: boolean = false, name: string = "") {
        this.isAlternateOption = isAlternateOption;
        this.name = name;
    }
}

export class GaragesAlternateOption {
    multiSpaceMeters: GaragesModel = new GaragesModel(true, "multiSpaceMeters");
}
//End : Garages Equipment Cost Model


export class CostLables {
    lables: any = {
        //On Street and Off Street properties
        "unitsOwned": "Quantity of Units Owned",
        "unitsPurchased": "Quantity of Units Purchased",
        "costOfBaseUnit": "Cost of Base Unit",
        "warrantyStartingYear": "Meter Warranty (applies starting in Year)",
        "monthlyMeterSoftwareFees": "Monthly Meter Software Fees - Per Unit",
        "monthlyCreditCardProcessingFees": "Monthly CC Processing Fees - Per Transaction**",
        "estimatedCreditCardTransaction": "Estimated # of Credit Card Trans Per Unit / Per Day",
        "isAlternateOption": "isAlternateOption",

        //Garages properties
        "garageAccessPoints": "Garage Access Points (Ingress/Egress) / Qty of Units",
        "ingressEgressEquipmentCost": "Ingress Egress Equipment Cost / Multispace Meter Cost",
        "payOnFootEquipWithBNA": "Pay on Foot Equip with BNA (1 Unit Per Garage)",
        "payOnFootEquipWithCreditCard": "Pay on Foot Equip with Credit Card (1 Unit Per Garage)",
        "annualSoftwareFeePerAccessPoint": "Annual Software Fee - Per Access Point / Unit",
        "warranty": "Warranty"
    };
    columnNames: Array<string> = ["unitsOwned", "unitsPurchased", "costOfBaseUnit", "warrantyStartingYear", "monthlyMeterSoftwareFees", "monthlyCreditCardProcessingFees", "estimatedCreditCardTransaction"];

    garagesColumnNames: Array<string> = ["unitsOwned", "unitsPurchased", "garageAccessPoints", "ingressEgressEquipmentCost", "payOnFootEquipWithBNA", "payOnFootEquipWithCreditCard", "annualSoftwareFeePerAccessPoint", "warranty", "monthlyCreditCardProcessingFees", "estimatedCreditCardTransaction"];

    onStreetAlternateColumns: Array<string> = ["singleSpaceMeters", "dualSpaceMeters", "payStations", "mobileOnly"];
    offStreetAlternateColumns: Array<string> = ["singleSpaceMeters"];
    garagesAlternateColumns: Array<string> = ["multiSpaceMeters"];
}

// export class GaragesEquipmentCostModel {
//     unitsOwned: number = 0;
//     unitsPurchased: number = 0;

//     garageAccessPoints: number = 0;
//     ingressEgressEquipmentCost: number = 0;

//     payOnFootEquipWithBNA: number = 0;
//     payOnFootEquipWithCreditCard: number = 0;

//     annualSoftwareFeePerAccessPoint: number = 0;
//     warranty: number = 0;

//     monthlyCreditCardProcessingFees: number = 0;
//     estimatedCreditCardTransaction: number = 0;
// }

// public class EquipmentCostOnStreetDto
// {
//     public int Id { get; set; }
//     public string Name { get; set; }
//     public int QuantityOfUnitsOwned { get; set; }
//     public int QuantityOfUnitsPurchased { get; set; }
//     public int CostOfBaseUnit { get; set; }
//     public int MeterWarranty { get; set; }
//     public int MonthlyMeterSoftwareFeesPerUnit { get; set; }
//     public int MonthlyCCProcessingFeesPerTransaction { get; set; }
//     public int EstimatedNumberOfCreditCardTransPerUnitPerDay { get; set; }
//     public bool IsAlternateOption { get; set; }
//     public int ClientId { get; set; }
// }

// public class EquipmentCostOffStreetDto
// {
//     public int Id { get; set; }
//     public string Name { get; set; }
//     public int QuantityOfUnitsOwned { get; set; }
//     public int QuantityOfUnitsPurchased { get; set; }
//     public int CostOfBaseUnit { get; set; }
//     public int MeterWarranty { get; set; }
//     public int MonthlyMeterSoftwareFeesPerUnit { get; set; }
//     public int MonthlyCCProcessingFeesPerTransaction { get; set; }
//     public int EstimatedNumberOfCreditCardTransPerUnitPerDay { get; set; }
//     public bool IsAlternateOption { get; set; }
//     public int ClientId { get; set; }
// }

// public class EquipmentCostGaragesDto
// {
//     public int Id { get; set; }
//     public string Name { get; set; }
//     public int QuantityOfUnitsPurchased { get; set; }
//     public int GarageAccessPointsIngressEgressQtyOfUnits { get; set; }
//     public int IngressEgressEquipmentCostMultispaceMeterCost { get; set; }
//     public int PayonFootEquipwithBNA1UnitPerGarage { get; set; }
//     public int PayonFootEquipwithCreditCard1UnitPerGarage { get; set; }
//     public int AnnualSoftwareFeePerAccessPointUnit { get; set; }
//     public int Warranty { get; set; }
//     public int MonthlyCCProcessingFeesPerTransaction { get; set; }
//     public int EstimatedNumberOfCreditCardTransPerUnitPerDay { get; set; }
//     public bool IsAlternateOption { get; set; }
//     public int ClientId { get; set; }
// }