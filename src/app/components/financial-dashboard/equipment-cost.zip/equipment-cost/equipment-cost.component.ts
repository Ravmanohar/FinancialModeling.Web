import { Component, OnInit } from '@angular/core';
import { EquipmentCostTabList, EquipmentCostTab } from 'src/app/components/financial-dashboard/financial-dashboard.models';

@Component({
  selector: 'app-equipment-cost',
  templateUrl: './equipment-cost.component.html',
  styleUrls: ['./equipment-cost.component.scss']
})
export class EquipmentCostComponent implements OnInit {

  constructor() { }

  activeTabName: string = "Equipment Cost On-street";

  isLoaded: boolean = true;
  ngOnInit() {
    this.addEquipmentCostTabs();
  }

  equipmentCostTabs: Array<EquipmentCostTab> = [];

  addEquipmentCostTabs() {
    let equipmentCostTabList: EquipmentCostTabList = new EquipmentCostTabList();
    console.log(equipmentCostTabList.equipmentTabs);
    let tabId: number = 0;
    for (var tabName of equipmentCostTabList.equipmentTabs) {
      console.log(tabName);
      let equipmentCostTab: EquipmentCostTab = new EquipmentCostTab();
      equipmentCostTab.tabId = tabId++;
      equipmentCostTab.tabName = tabName;
      this.equipmentCostTabs.push(equipmentCostTab);
    }
  }

  onTabChange(tab: EquipmentCostTab) {
    this.activeTabName = tab.tabName;
  }

}
