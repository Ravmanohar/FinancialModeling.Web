import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-garages-equipment-cost',
  templateUrl: './garages-equipment-cost.component.html',
  styleUrls: ['./garages-equipment-cost.component.scss']
})
export class GaragesEquipmentCostComponent implements OnInit {

  @Input() private locationType: string;

  constructor() { }

  ngOnInit() {
  }
}
