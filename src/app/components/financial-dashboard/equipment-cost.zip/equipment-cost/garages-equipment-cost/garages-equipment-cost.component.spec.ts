import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GaragesEquipmentCostComponent } from './garages-equipment-cost.component';

describe('GaragesEquipmentCostComponent', () => {
  let component: GaragesEquipmentCostComponent;
  let fixture: ComponentFixture<GaragesEquipmentCostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GaragesEquipmentCostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GaragesEquipmentCostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
