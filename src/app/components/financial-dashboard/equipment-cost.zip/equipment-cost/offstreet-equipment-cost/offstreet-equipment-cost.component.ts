import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-offstreet-equipment-cost',
  templateUrl: './offstreet-equipment-cost.component.html',
  styleUrls: ['./offstreet-equipment-cost.component.scss']
})
export class OffstreetEquipmentCostComponent implements OnInit {

  @Input() private locationType: string;

  constructor() { }

  ngOnInit() {
  }

}
