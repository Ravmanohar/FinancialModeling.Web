import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OffstreetEquipmentCostComponent } from './offstreet-equipment-cost.component';

describe('OffstreetEquipmentCostComponent', () => {
  let component: OffstreetEquipmentCostComponent;
  let fixture: ComponentFixture<OffstreetEquipmentCostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OffstreetEquipmentCostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OffstreetEquipmentCostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
