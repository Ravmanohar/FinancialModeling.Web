import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EquipmentCostComponent } from './equipment-cost.component';

describe('EquipmentCostComponent', () => {
  let component: EquipmentCostComponent;
  let fixture: ComponentFixture<EquipmentCostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EquipmentCostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EquipmentCostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
