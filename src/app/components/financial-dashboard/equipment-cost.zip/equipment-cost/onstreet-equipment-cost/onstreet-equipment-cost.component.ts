import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-onstreet-equipment-cost',
  templateUrl: './onstreet-equipment-cost.component.html',
  styleUrls: ['./onstreet-equipment-cost.component.scss']
})
export class OnstreetEquipmentCostComponent implements OnInit {

  @Input() private locationType: string;

  constructor() { }

  ngOnInit() {
  }
}
