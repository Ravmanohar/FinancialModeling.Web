import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnstreetEquipmentCostComponent } from './onstreet-equipment-cost.component';

describe('OnstreetEquipmentCostComponent', () => {
  let component: OnstreetEquipmentCostComponent;
  let fixture: ComponentFixture<OnstreetEquipmentCostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnstreetEquipmentCostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnstreetEquipmentCostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
