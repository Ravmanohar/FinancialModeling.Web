import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { OnStreetEquipmentCostModel, GaragesEquipmentCostModel, OffStreetEquipmentCostModel, OnStreetModel, CostLables, OffStreetModel, GaragesModel } from 'src/app/models/setup-equipment-cost.model';

@Component({
  selector: 'app-setup-equipment-cost',
  templateUrl: './setup-equipment-cost.component.html',
  styleUrls: ['./setup-equipment-cost.component.scss']
})
export class SetupEquipmentCostComponent implements OnInit {

  @Input() private ClientInfo: any = null;
  @Input() private ParkingType: any = null;

  @Input() private onParentCommand: EventEmitter<string>;
  @Output() onChildAction: EventEmitter<string> = new EventEmitter();

  parkingTypeId: number
  constructor() {

  }

  onStreetECM: OnStreetEquipmentCostModel = new OnStreetEquipmentCostModel();
  offStreetECM: OffStreetEquipmentCostModel = new OffStreetEquipmentCostModel();
  garagesECM: GaragesEquipmentCostModel = new GaragesEquipmentCostModel();
  costLables: CostLables = new CostLables();
  ngOnInit() {
    this.parkingTypeId = this.ParkingType.parkingTypeId;

    if (this.onParentCommand) {
      this.onParentCommandSubscription = this.onParentCommand.subscribe(commandName => {
        console.log(commandName);
        switch (commandName) {
          case "SetupEquipmentCost":
            this.onSaveEquipmentCost();
            break;
          default:
            break;
        }
      });
    }

    console.log(this.ClientInfo);
    console.log(this.ParkingType);
    console.log(this.onStreetECM);

    // ParkingType.parkingTypeId == 1
    switch (this.ParkingType.parkingTypeId) {
      case 1://<!-- On Street -->
        this.onStreetAddZone();
        break;
      case 2://<!-- Off Street -->
        this.offStreetAddZone();
        break;
      case 3://<!-- Garages -->
        this.garagesStreetAddZone();
        break;
    }
  }

  onStreetAddZone() {
    let zoneName: string = "Zone " + (this.onStreetECM.singleSpaceMeters.length + 1);
    let singleSpaceMeter: OnStreetModel = new OnStreetModel(false, zoneName);
    singleSpaceMeter.clientId = this.ClientInfo.clientId;
    this.onStreetECM.singleSpaceMeters.push(singleSpaceMeter);
  }

  offStreetAddZone() {
    let zoneName: string = "Zone " + (this.offStreetECM.multiSpaceMeters.length + 1);
    let singleSpaceMeter: OffStreetModel = new OffStreetModel(false, zoneName);
    singleSpaceMeter.clientId = this.ClientInfo.clientId;
    this.offStreetECM.multiSpaceMeters.push(singleSpaceMeter);
  }

  garagesStreetAddZone() {
    let zoneName: string = "Zone " + (this.garagesECM.garagesModels.length + 1);
    let garagesModel: GaragesModel = new GaragesModel(false, zoneName);
    garagesModel.clientId = this.ClientInfo.clientId;
    this.garagesECM.garagesModels.push(garagesModel);
  }

  onStreetRemoveZone(singleSpaceMeter, removeIndex) {
    this.onStreetECM.singleSpaceMeters.splice(removeIndex, 1);
  }
  offStreetRemoveZone(multiSpaceMeter, removeIndex) {
    this.offStreetECM.multiSpaceMeters.splice(removeIndex, 1);
  }
  garagesRemoveZone(garagesModel, removeIndex) {
    this.garagesECM.garagesModels.splice(removeIndex, 1);
  }

  private onParentCommandSubscription: any;
  ngOnDestroy() {
    if (this.onParentCommand) {
      this.onParentCommandSubscription.unsubscribe();
    }
  }

  onSaveEquipmentCost() {
    this.onStreetECM.alternateOptions.dualSpaceMeters.clientId = this.ClientInfo.clientId;
    this.onStreetECM.alternateOptions.payStations.clientId = this.ClientInfo.clientId;
    this.onStreetECM.alternateOptions.mobileOnly.clientId = this.ClientInfo.clientId;
    console.log("SetupEquipmentCost", this.onStreetECM);
  }

}
