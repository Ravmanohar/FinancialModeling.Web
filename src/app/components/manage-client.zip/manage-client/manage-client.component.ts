import { Component, OnInit } from '@angular/core';
import { LookupService, AdminService } from '../../services';
import { Router } from '@angular/router';
import { ParkingClientModel } from 'src/app/models/add-client-model';

declare var $;
@Component({
  selector: 'app-manage-client',
  templateUrl: './manage-client.component.html',
  styleUrls: ['./manage-client.component.scss']
})
export class ManageClientComponent implements OnInit {

  constructor(private router: Router, private lookupService: LookupService) { }

  currentClient: ParkingClientModel;
  ngOnInit() {
    this.currentClient = JSON.parse(localStorage.getItem('CurrentClient'));
    console.log(this.currentClient);
  }

  activeTabName: string = "setup-model-tab";// "projections-tab";
  onTabChange(tabName: string) {
    this.activeTabName = tabName;
  }

  onModelCreated(tabName: string) {
    this.activeTabName = tabName;
  }

  goToViewClient() {
    this.router.navigate(['view-clients']);
  }

}
