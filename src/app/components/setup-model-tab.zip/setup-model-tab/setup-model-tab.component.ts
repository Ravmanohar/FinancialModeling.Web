import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { AdminService, LookupService } from 'src/app/services';
import { ParkingModelCombination } from 'src/app/services/lookup.service';
import { HttpErrorResponse } from '@angular/common/http';
import { FinancialDashboardDto } from 'src/app/components/financial-dashboard/financial-dashboard.models';
import { SetupHourlyModelDto, HourlyZone } from 'src/app/models/setup.model.index';
import { EscalatingZone, EscalatingOperatingHour, SetupEscalatingModelDto } from 'src/app/models/setup-escalating-model';
// import { SetupEscalatingModelDto, EscalatingZone } from 'src/app/models/setup-escalating-model';
// import { HoursOfOperation } from 'src/app/models/setup-timeofday-model';

declare var $;
declare var toastr;
@Component({
  selector: 'app-setup-model-tab',
  templateUrl: './setup-model-tab.component.html',
  styleUrls: ['./setup-model-tab.component.scss']
})
export class SetupModelTabComponent implements OnInit {

  @Output() onModelCreated: EventEmitter<string> = new EventEmitter();

  constructor(
    public lookupService: LookupService,
    public adminService: AdminService
  ) { }

  clientInfo: any = {};
  private onParentCommand: EventEmitter<string> = new EventEmitter();
  ngOnInit() {
    this.clientInfo = JSON.parse(localStorage.getItem('CurrentClient'));
    console.log("clientInfo :", this.clientInfo);
    this.getClientModels();

    // let setupTimeOfDayModelDto: SetupTimeOfDayModelDto = new SetupTimeOfDayModelDto();
    // let timeOfDayZone: TimeOfDayZone = new TimeOfDayZone();
    // timeOfDayZone.peakHoursOfOperations.push(
    //   new HoursOfOperation(),
    //   new HoursOfOperation(),
    // );
    // timeOfDayZone.hoursOfOperationDailyPeak.push(
    //   new HoursOfOperation(),
    //   new HoursOfOperation(),
    // );
    // setupTimeOfDayModelDto.timeOfDayZones.push(timeOfDayZone);
    // setupTimeOfDayModelDto.timeOfDayZones.push(JSON.parse(JSON.stringify(timeOfDayZone)));
    // console.log("setupTimeOfDayModelDto", setupTimeOfDayModelDto);


    let setupEscalatingModelDto: SetupEscalatingModelDto = new SetupEscalatingModelDto();
    let escalatingZone: EscalatingZone = new EscalatingZone();
    escalatingZone.escalatingOperatingHourDaily = new EscalatingOperatingHour();
    escalatingZone.escalatingOperatingHourEvening = new EscalatingOperatingHour();
    setupEscalatingModelDto.escalatingZones.push(escalatingZone);
    setupEscalatingModelDto.escalatingZones.push(escalatingZone);
    console.log("setupEscalatingModelDto", setupEscalatingModelDto);

    // let setupHourlyModelDto: SetupHourlyModelDto = new SetupHourlyModelDto();
    // let hourlyZone: HourlyZone = new HourlyZone();
    // setupHourlyModelDto.hourlyZones.push(hourlyZone);
    // setupHourlyModelDto.hourlyZones.push(hourlyZone);
    // console.log("setupHourlyModelDto", setupHourlyModelDto);
  }

  isShowLoader: boolean = false;
  financialDashboard: FinancialDashboardDto = new FinancialDashboardDto();
  // propertyNames: Array<string> = [
  //   "hourlyOnStreet",
  //   "hourlyOffStreet",
  //   "hourlyGarages",
  //   "timeOfDayOnStreet",
  //   "timeOfDayOffStreet",
  //   "timeOfDayGarages",
  //   "escalatingOnStreet",
  //   "escalatingOffStreet",
  //   "escalatingGarages"
  // ];
  propertyNames: Array<string> = [
    "hourlyOnStreet",
    "timeOfDayOnStreet",
    "escalatingOnStreet",
    "hourlyOffStreet",
    "timeOfDayOffStreet",
    "escalatingOffStreet",
    "hourlyGarages",
    "timeOfDayGarages",
    "escalatingGarages"
  ];
  getClientModels() {
    this.isShowLoader = true;
    let clientId: number = this.clientInfo.clientId;
    this.adminService.getClientModels(clientId)
      .subscribe((financialDashboard: FinancialDashboardDto) => {
        console.log(financialDashboard);
        this.financialDashboard = financialDashboard;
        this.isShowLoader = false;
      },
      (errorResponse: HttpErrorResponse) => {
        toastr.error("Get Client Models", "Error");
      });
  }

  isShowModal: boolean = false;
  selectedModelName: string = "";
  onShowSetupClientModel(modelName: string) {
    this.isShowModal = true;
    this.selectedModelName = modelName;
    setTimeout(() => { $("#setup-model-popup").modal('show'); }, 100);
  }
  closeSetupModelPopup() {
    $("#setup-model-popup").modal('hide');
    setTimeout(() => { this.isShowModal = false; }, 100);
  }

  onUpdateClientModel() {
    // this.onParentCommand.emit("CreateModel");
    this.onParentCommand.emit("UpdateModel");
  }

  onAddZone() {
    this.onParentCommand.emit("AddZone");
  }

  onChildAction(childActionName: string) {
    console.log("childActionName", childActionName);
    switch (childActionName) {
      case "onModelCreated":
        this.closeSetupModelPopup();
        break;
      default:
        break;
    }
  }



  // Start : Paid Parking Equipment Costs
  parkingTypes: any = this.lookupService.lookup.parkingTypes;
  selectedParkingType: any = null;
  onSetupEquipmentCost(parkingType) {
    console.log(parkingType);
    this.selectedParkingType = parkingType;
    this.onShowSetupEquipmentCostModal();
  }

  isShowSetupEquipmentCostModal: boolean = false;
  onShowSetupEquipmentCostModal() {
    this.isShowSetupEquipmentCostModal = true;
    // this.clientInfo
    setTimeout(() => { $("#setup-equipment-cost-modal").modal('show'); }, 100);
  }

  onCloseSetupEquipmentCostModal() {
    $("#setup-equipment-cost-modal").modal('hide');
    setTimeout(() => { this.isShowSetupEquipmentCostModal = false; }, 100);
  }
  onSaveSetupEquipmentCostModal() {
    this.onParentCommand.emit("SetupEquipmentCost");
  }
  // End : Paid Parking Equipment Costs

}
