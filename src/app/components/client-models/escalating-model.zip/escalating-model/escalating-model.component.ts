import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

import { LookupService, AdminService } from '../../../services';
import { FinancialDashboardService } from 'src/app/components/financial-dashboard/financial-dashboard.service';
import { FinancialDashboardDto } from 'src/app/models/setup.model.index';
import { SetupEscalatingModelDto, EscalatingZone } from 'src/app/models/setup-escalating-model';
import { HoursOfOperation } from 'src/app/models/setup-timeofday-model';
import { EscalatingService } from 'src/app/services/model.services.index';


declare var $;
declare var moment;
declare var toastr;
@Component({
  selector: 'app-escalating-model',
  templateUrl: './escalating-model.component.html',
  styleUrls: ['./escalating-model.component.scss']
})
export class EscalatingModelComponent implements OnInit {
  @Input() private onParentCommand: EventEmitter<string>;

  @Output() onChildAction: EventEmitter<string> = new EventEmitter();

  @Input() private modelName: string;
  @Input() private financialDashboard: FinancialDashboardDto;
  constructor(
    private financialDashboardService: FinancialDashboardService,
    private changeDetector: ChangeDetectorRef,
    private escalatingService: EscalatingService) {

  }

  locationTypes: any = {
    escalatingOnStreet: "ON-STREET",
    escalatingOffStreet: "OFF-STREET",
    escalatingGarages: "GARAGES",
  }
  locationName: string = "";

  isProjectionChanged: boolean = false;
  onParentCommandSubscription: any = null
  ngOnInit() {
    console.log(this.financialDashboard);
    if (this.onParentCommand) {
      this.onParentCommandSubscription = this.onParentCommand.subscribe(commandName => {
        console.log(commandName);
        switch (commandName) {
          case "UpdateModel":
            console.log(this.escalatingModel);
            break;
          default:
            break;
        }
      });
    }
    this.locationName = this.locationTypes[this.modelName];
    this.loadEscalatingModelSetup();
  }

  loadEscalatingModelSetup() {
    $(document).ready((e) => {
      // $("#hourly-revenue-container").on('click', ".report-title", (e) => {
      //   $(e.currentTarget).parent('.report-container').find('.table-container').slideToggle();
      //   $(e.currentTarget).toggleClass('open');
      // });

      // $("#tbl-hrm-on-street input").unbind("input");
      $("#escalating-model-container").on("input", "#tbl-hrm-on-street input", (e) => {
        // $("#tbl-hrm-on-street input").on("input", (e) => {
        // this.isProjectionChanged = true;
        // var propertyName = e.currentTarget.name;
        // var fieldType = e.currentTarget.type;
        // var value = e.currentTarget.value;
        // if (fieldType != "time") {
        //   var maxValue = Number($(e.currentTarget).attr("max"));
        //   var currValue = Number(e.currentTarget.value);
        //   if (currValue > maxValue)
        //     value = maxValue;
        // }
        // e.currentTarget.value = value;

        // var zoneId = Number(e.currentTarget.getAttribute("zoneId"));
        // if (zoneId > 0) {
        //   let zone: HourlyParkingZone = this.hourlyModel.clientParkingZones.find(x => x.zoneId == zoneId);
        //   if (fieldType != "time") {
        //     zone[propertyName] = value;
        //   } else {
        //     var hour = zone.clientOperatingHour;
        //     switch (propertyName) {
        //       case "startTime":
        //         hour.operatingHoursStart = value;
        //         break;
        //       case "endTime":
        //         hour.operatingHoursEnd = value;
        //         break;
        //       default:
        //         break;
        //     }
        //   }
        // }
        // this.changeDetector.detectChanges();
      });

      this.loadEscalatingModelByLocationType();
    });
  }

  isShowLoader: boolean = false;
  escalatingModel: SetupEscalatingModelDto = null;
  loadEscalatingModelByLocationType() {
    switch (this.modelName) {
      case "escalatingOnStreet":
        this.escalatingModel = this.financialDashboard.escalatingOnStreet;
        break;
      case "escalatingOffStreet":
        this.escalatingModel = this.financialDashboard.escalatingOffStreet;
        break;
      case "escalatingGarages":
        this.escalatingModel = this.financialDashboard.escalatingGarages;
        break;
      default:
        break;
    }

    this.changeDetector.detectChanges();

    //If no model created then return
    if (this.escalatingModel == null)
      return false;

    this.loadEscalatingModel();
  }

  loadEscalatingModel() {
    // console.log(this.timeOfDayModel);
    this.escalatingService.renderEscalatingRevenueModel(this.escalatingModel.escalatingZones);
  }

}