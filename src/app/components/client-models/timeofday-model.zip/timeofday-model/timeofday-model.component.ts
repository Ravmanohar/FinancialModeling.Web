import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

import { LookupService, AdminService } from '../../../services';
import { TimeOfDayService } from 'src/app/services/model.services.index';
import { FinancialDashboardService } from 'src/app/components/financial-dashboard/financial-dashboard.service';

import { HourlyRevenueModel, SetupTimeOfDayModelDto, FinancialDashboardDto } from 'src/app/models/setup.model.index';
import { TimeOfDayZone, HoursOfOperation } from 'src/app/models/setup-timeofday-model';

declare var $;
declare var moment;
declare var toastr;
@Component({
  selector: 'app-timeofday-model',
  templateUrl: './timeofday-model.component.html',
  styleUrls: ['./timeofday-model.component.scss']
})
export class TimeofdayModelComponent implements OnInit {
  @Input() private onParentCommand: EventEmitter<string>;

  @Output() onChildAction: EventEmitter<string> = new EventEmitter();

  @Input() private modelName: string;
  @Input() private financialDashboard: FinancialDashboardDto;
  constructor(
    private financialDashboardService: FinancialDashboardService,
    private changeDetector: ChangeDetectorRef,
    private timeOfDayService: TimeOfDayService) {

  }

  locationTypes: any = {
    timeOfDayOnStreet: "ON-STREET",
    timeOfDayOffStreet: "OFF-STREET",
    timeOfDayGarages: "GARAGES",
  }
  locationName: string = "";

  isProjectionChanged: boolean = false;
  onParentCommandSubscription: any = null
  ngOnInit() {
    console.log(this.financialDashboard);
    if (this.onParentCommand) {
      this.onParentCommandSubscription = this.onParentCommand.subscribe(commandName => {
        console.log(commandName);
        switch (commandName) {
          case "UpdateModel":
            console.log(this.timeOfDayModel);
            break;
          default:
            break;
        }
      });
    }
    this.locationName = this.locationTypes[this.modelName];
    this.loadHourlyModelSetup();
  }

  loadHourlyModelSetup() {
    $(document).ready((e) => {
      // $("#hourly-revenue-container").on('click', ".report-title", (e) => {
      //   $(e.currentTarget).parent('.report-container').find('.table-container').slideToggle();
      //   $(e.currentTarget).toggleClass('open');
      // });

      // $("#tbl-hrm-on-street input").unbind("input");
      $("#timeofday-model-container").on("input", "#tbl-hrm-on-street input", (e) => {
        // $("#tbl-hrm-on-street input").on("input", (e) => {
        // this.isProjectionChanged = true;
        // var propertyName = e.currentTarget.name;
        // var fieldType = e.currentTarget.type;
        // var value = e.currentTarget.value;
        // if (fieldType != "time") {
        //   var maxValue = Number($(e.currentTarget).attr("max"));
        //   var currValue = Number(e.currentTarget.value);
        //   if (currValue > maxValue)
        //     value = maxValue;
        // }
        // e.currentTarget.value = value;

        // var zoneId = Number(e.currentTarget.getAttribute("zoneId"));
        // if (zoneId > 0) {
        //   let zone: HourlyParkingZone = this.hourlyModel.clientParkingZones.find(x => x.zoneId == zoneId);
        //   if (fieldType != "time") {
        //     zone[propertyName] = value;
        //   } else {
        //     var hour = zone.clientOperatingHour;
        //     switch (propertyName) {
        //       case "startTime":
        //         hour.operatingHoursStart = value;
        //         break;
        //       case "endTime":
        //         hour.operatingHoursEnd = value;
        //         break;
        //       default:
        //         break;
        //     }
        //   }
        // }
        // this.changeDetector.detectChanges();
      });

      this.loadTimeOfDayModelByLocationType();
    });
  }

  isShowLoader: boolean = false;
  timeOfDayModel: SetupTimeOfDayModelDto = null;
  loadTimeOfDayModelByLocationType() {
    switch (this.modelName) {
      case "timeOfDayOnStreet":
        this.timeOfDayModel = this.financialDashboard.timeOfDayOnStreet;
        break;
      case "timeOfDayOffStreet":
        this.timeOfDayModel = this.financialDashboard.timeOfDayOffStreet;
        break;
      case "timeOfDayGarages":
        this.timeOfDayModel = this.financialDashboard.timeOfDayGarages;
        break;
      default:
        break;
    }

    this.changeDetector.detectChanges();

    //If no model created then return
    if (this.timeOfDayModel == null)
      return false;

    this.loadTimeOfDayModel();
  }

  loadTimeOfDayModel() {
    // console.log(this.timeOfDayModel);
    this.timeOfDayService.renderTimeOfDayRevenueModel(this.timeOfDayModel.timeOfDayZones);
  }

  onAddTimeSlot() {
    var numberOfTimeSlots = this.timeOfDayModel.timeOfDayZones[0].hoursOfOperations.length;
    if (numberOfTimeSlots >= 5) {
      toastr.info("You can add maximum 5 slots", "Info");
      return false;
    }
    var startTime = $("#input-start-time").val();
    var endTime = $("#input-end-time").val();
    this.timeOfDayModel.timeOfDayZones.forEach((timeOfDayZone: TimeOfDayZone) => {
      let hoursOfOperation: HoursOfOperation = new HoursOfOperation();
      hoursOfOperation.peakOperatingHoursStart = startTime;
      hoursOfOperation.peakOperatingHoursEnd = endTime;
      hoursOfOperation.nonPeakOperatingHoursStart = startTime;
      hoursOfOperation.nonPeakOperatingHoursEnd = endTime;
      timeOfDayZone.hoursOfOperations.push(hoursOfOperation);
    });
    this.timeOfDayService.renderTimeOfDayRevenueModel(this.timeOfDayModel.timeOfDayZones);
  }

}