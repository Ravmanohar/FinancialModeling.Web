import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

import { LookupService, AdminService } from '../../../services';
import { FinancialDashboardService } from 'src/app/components/financial-dashboard/financial-dashboard.service';
import { FinancialDashboardDto } from 'src/app/components/financial-dashboard/financial-dashboard.models';

import { SetupHourlyModelDto } from 'src/app/models/setup.model.index';
import { HourlyService } from 'src/app/services/model.services.index';

declare var $;
declare var moment;
declare var toastr;
@Component({
  selector: 'app-hourly-model',
  templateUrl: './hourly-model.component.html',
  styleUrls: ['./hourly-model.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class HourlyModelComponent implements OnInit {
  @Input() private onParentCommand: EventEmitter<string>;

  @Output() onChildAction: EventEmitter<string> = new EventEmitter();

  @Input() private modelName: string;
  @Input() private financialDashboard: FinancialDashboardDto;
  constructor(
    private financialDashboardService: FinancialDashboardService,
    private changeDetector: ChangeDetectorRef,
    private hourlyService: HourlyService) {

  }

  locationTypes: any = {
    hourlyOnStreet: "ON-STREET",
    hourlyOffStreet: "OFF-STREET",
    hourlyGarages: "GARAGES",
  }
  locationName: string = "";

  isProjectionChanged: boolean = false;
  onParentCommandSubscription: any = null
  ngOnInit() {
    console.log(this.financialDashboard);
    if (this.onParentCommand) {
      this.onParentCommandSubscription = this.onParentCommand.subscribe(commandName => {
        console.log(commandName);
        switch (commandName) {
          case "UpdateModel":
            console.log(this.hourlyModel);
            break;
          default:
            break;
        }
      });
    }
    this.locationName = this.locationTypes[this.modelName];
    this.loadEscalatingModelSetup();
  }

  loadEscalatingModelSetup() {
    $(document).ready((e) => {
      // $("#hourly-revenue-container").on('click', ".report-title", (e) => {
      //   $(e.currentTarget).parent('.report-container').find('.table-container').slideToggle();
      //   $(e.currentTarget).toggleClass('open');
      // });

      // $("#tbl-hrm-on-street input").unbind("input");
      $("#escalating-model-container").on("input", "#tbl-hrm-on-street input", (e) => {
        // $("#tbl-hrm-on-street input").on("input", (e) => {
        // this.isProjectionChanged = true;
        // var propertyName = e.currentTarget.name;
        // var fieldType = e.currentTarget.type;
        // var value = e.currentTarget.value;
        // if (fieldType != "time") {
        //   var maxValue = Number($(e.currentTarget).attr("max"));
        //   var currValue = Number(e.currentTarget.value);
        //   if (currValue > maxValue)
        //     value = maxValue;
        // }
        // e.currentTarget.value = value;

        // var zoneId = Number(e.currentTarget.getAttribute("zoneId"));
        // if (zoneId > 0) {
        //   let zone: HourlyParkingZone = this.hourlyModel.clientParkingZones.find(x => x.zoneId == zoneId);
        //   if (fieldType != "time") {
        //     zone[propertyName] = value;
        //   } else {
        //     var hour = zone.clientOperatingHour;
        //     switch (propertyName) {
        //       case "startTime":
        //         hour.operatingHoursStart = value;
        //         break;
        //       case "endTime":
        //         hour.operatingHoursEnd = value;
        //         break;
        //       default:
        //         break;
        //     }
        //   }
        // }
        // this.changeDetector.detectChanges();
      });

      this.loadEscalatingModelByLocationType();
    });
  }

  isShowLoader: boolean = false;
  hourlyModel: SetupHourlyModelDto = null;
  loadEscalatingModelByLocationType() {
    switch (this.modelName) {
      case "hourlyOnStreet":
        this.hourlyModel = this.financialDashboard.hourlyOnStreet;
        break;
      case "hourlyOffStreet":
        this.hourlyModel = this.financialDashboard.hourlyOffStreet;
        break;
      case "hourlyGarages":
        this.hourlyModel = this.financialDashboard.hourlyGarages
        break;
      default:
        break;
    }

    this.changeDetector.detectChanges();

    //If no model created then return
    if (this.hourlyModel == null)
      return false;

    this.renderSetupHourlyModel();
  }

  columnDefs: any = [];
  columns: any = [];
  isCalculated: boolean = false;
  renderSetupHourlyModel() {
    // console.log(this.timeOfDayModel);
    this.hourlyService.renderSetupHourlyModel(this.hourlyModel.hourlyZones, this.locationName);

    //Ng Approch
    // let hourlyModelCalculated = this.hourlyService.getHourlyModel(this.hourlyModel);
    // this.hourlyModel = hourlyModelCalculated.hourlyModel;
    // this.columnDefs = hourlyModelCalculated.columns;
    // this.columns = Object.keys(this.columnDefs);
    // this.isCalculated = true;
    // this.changeDetector.detectChanges();
  }
}  